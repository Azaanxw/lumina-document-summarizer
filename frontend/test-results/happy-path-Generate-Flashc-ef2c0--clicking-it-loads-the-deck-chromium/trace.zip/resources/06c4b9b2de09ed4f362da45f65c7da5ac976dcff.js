(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/pdf-viewer-client.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PdfViewer",
    ()=>PdfViewer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$pdf$2f$dist$2f$Document$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Document$3e$__ = __turbopack_context__.i("[project]/node_modules/react-pdf/dist/Document.js [app-client] (ecmascript) <export default as Document>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$pdf$2f$dist$2f$Page$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Page$3e$__ = __turbopack_context__.i("[project]/node_modules/react-pdf/dist/Page.js [app-client] (ecmascript) <export default as Page>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__pdfjs$3e$__ = __turbopack_context__.i("[project]/node_modules/pdfjs-dist/build/pdf.mjs [app-client] (ecmascript) <export * as pdfjs>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/skeleton.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__pdfjs$3e$__["pdfjs"].GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__pdfjs$3e$__["pdfjs"].version}/build/pdf.worker.min.mjs`;
const normWord = (w)=>w.normalize("NFKD").replace(/[^a-z0-9]/gi, "").toLowerCase();
// Returns the set of itemIndex values (matching react-pdf's customTextRenderer itemIndex)
// that correspond to the citation snippets on the page.
//
// Uses concatenated-string substring search rather than token-by-token matching so that
// words split across adjacent text items (e.g. "60" + "-65%" rendering as two items
// instead of one) still match a snippet that contains "60-65%" as a single word.
function findMatchedItemIndices(pageItems, snippetTexts) {
    // Build per-token metadata: normalised form, source itemIdx, and position range
    // inside the concatenated page string.
    const tokens = [];
    let concatPage = "";
    for (const { str, idx } of pageItems){
        for (const raw of str.split(/\s+/)){
            const n = normWord(raw);
            if (!n) continue;
            tokens.push({
                norm: n,
                itemIdx: idx,
                start: concatPage.length,
                end: concatPage.length + n.length
            });
            concatPage += n;
        }
    }
    const matched = new Set();
    for (const text of snippetTexts){
        const snippetWords = text.split(/\s+/).map(normWord).filter(Boolean);
        if (snippetWords.length < 2) continue;
        const snippetConcat = snippetWords.join("");
        // Primary: substring search on the concatenated string.
        // Immune to how the PDF renderer splits words across text items.
        const pos = concatPage.indexOf(snippetConcat);
        if (pos !== -1) {
            const end = pos + snippetConcat.length;
            for (const tok of tokens){
                if (tok.start < end && tok.end > pos) matched.add(tok.itemIdx);
            }
            continue;
        }
        // Fallback: exact token-by-token sequential match.
        // Catches cases where normWord produces different results between snippet and page
        // (e.g. different Unicode normalisation applied by the backend extractor).
        outer: for(let i = 0; i <= tokens.length - snippetWords.length; i++){
            for(let j = 0; j < snippetWords.length; j++){
                if (tokens[i + j].norm !== snippetWords[j]) continue outer;
            }
            for(let j = 0; j < snippetWords.length; j++)matched.add(tokens[i + j].itemIdx);
            break;
        }
    // No fuzzy fallback — partial matches produce too many false positives.
    }
    // Fill in punctuation-only items that sit between matched items.
    // Characters like "–" and "-" normalize to "" so they never enter the token stream,
    // but they visually belong inside the highlighted run (e.g. "60–65%", "three-second").
    if (matched.size > 1) {
        const sorted = [
            ...matched
        ].sort((a, b)=>a - b);
        for(let i = 0; i < sorted.length - 1; i++){
            const lo = sorted[i], hi = sorted[i + 1];
            for (const { str, idx } of pageItems){
                if (idx > lo && idx < hi && !normWord(str)) matched.add(idx);
            }
        }
    }
    return matched;
}
function PdfViewer({ documentId, ref }) {
    _s();
    const [numPages, setNumPages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [containerWidth, setContainerWidth] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [highlight, setHighlight] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Set of itemIndex values to highlight on the cited page
    const [highlightedItems, setHighlightedItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const pageRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Map());
    // Text items per page, stored when onGetTextSuccess fires
    const pageTextItems = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Map());
    // Ref so callbacks can read the latest highlight without stale closure
    const highlightRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const pdfUrl = `${("TURBOPACK compile-time value", "http://localhost:8000")}/documents/${documentId}/pdf`;
    // Keep ref in sync on every render (no dependency array — runs every render)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PdfViewer.useEffect": ()=>{
            highlightRef.current = highlight;
        }
    }["PdfViewer.useEffect"]);
    // Track container width for responsive page rendering
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PdfViewer.useEffect": ()=>{
            if (!containerRef.current) return;
            const ro = new ResizeObserver({
                "PdfViewer.useEffect": (entries)=>{
                    setContainerWidth(entries[0]?.contentRect.width ?? 0);
                }
            }["PdfViewer.useEffect"]);
            ro.observe(containerRef.current);
            return ({
                "PdfViewer.useEffect": ()=>ro.disconnect()
            })["PdfViewer.useEffect"];
        }
    }["PdfViewer.useEffect"], []);
    // Track which page is most visible to show in the fixed indicator
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PdfViewer.useEffect": ()=>{
            if (numPages === 0) return;
            const visibleRatios = new Map();
            const io = new IntersectionObserver({
                "PdfViewer.useEffect": (entries)=>{
                    for (const entry of entries){
                        const page = Number(entry.target.dataset.page);
                        visibleRatios.set(page, entry.intersectionRatio);
                    }
                    let best = 1, bestRatio = -1;
                    visibleRatios.forEach({
                        "PdfViewer.useEffect": (ratio, page)=>{
                            if (ratio > bestRatio) {
                                bestRatio = ratio;
                                best = page;
                            }
                        }
                    }["PdfViewer.useEffect"]);
                    setCurrentPage(best);
                }
            }["PdfViewer.useEffect"], {
                root: containerRef.current,
                threshold: Array.from({
                    length: 11
                }, {
                    "PdfViewer.useEffect": (_, i)=>i / 10
                }["PdfViewer.useEffect"])
            });
            pageRefs.current.forEach({
                "PdfViewer.useEffect": (el)=>io.observe(el)
            }["PdfViewer.useEffect"]);
            return ({
                "PdfViewer.useEffect": ()=>io.disconnect()
            })["PdfViewer.useEffect"];
        }
    }["PdfViewer.useEffect"], [
        numPages
    ]);
    // Imperative handle for citation navigation
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(ref, {
        "PdfViewer.useImperativeHandle": ()=>({
                scrollToPage (pageNumber, snippets) {
                    const el = pageRefs.current.get(pageNumber);
                    if (el) el.scrollIntoView({
                        behavior: "smooth",
                        block: "start"
                    });
                    if (snippets?.length) setHighlight({
                        page: pageNumber,
                        texts: snippets
                    });
                }
            })
    }["PdfViewer.useImperativeHandle"]);
    // When highlight changes, immediately match if the page's text is already cached
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PdfViewer.useEffect": ()=>{
            if (!highlight) {
                setHighlightedItems(null);
                return;
            }
            const items = pageTextItems.current.get(highlight.page);
            if (items) {
                setHighlightedItems({
                    page: highlight.page,
                    items: findMatchedItemIndices(items, highlight.texts)
                });
            } else {
                setHighlightedItems(null); // Will be computed in handleTextSuccess once text loads
            }
        }
    }["PdfViewer.useEffect"], [
        highlight
    ]);
    // Cache text items per page; if this is the cited page, compute highlighted indices
    const handleTextSuccess = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PdfViewer.useCallback[handleTextSuccess]": (pageNumber, textContent)=>{
            const items = textContent.items.map({
                "PdfViewer.useCallback[handleTextSuccess].items": (item, idx)=>({
                        str: item["str"],
                        idx
                    })
            }["PdfViewer.useCallback[handleTextSuccess].items"]).filter({
                "PdfViewer.useCallback[handleTextSuccess].items": (x)=>typeof x.str === "string" && x.str.length > 0
            }["PdfViewer.useCallback[handleTextSuccess].items"]);
            pageTextItems.current.set(pageNumber, items);
            const hl = highlightRef.current;
            if (hl?.page === pageNumber) {
                setHighlightedItems({
                    page: pageNumber,
                    items: findMatchedItemIndices(items, hl.texts)
                });
            }
        }
    }["PdfViewer.useCallback[handleTextSuccess]"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative h-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: containerRef,
                className: "h-full overflow-y-auto bg-muted/30",
                children: containerWidth > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$pdf$2f$dist$2f$Document$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Document$3e$__["Document"], {
                    file: pdfUrl,
                    onLoadSuccess: ({ numPages })=>setNumPages(numPages),
                    loading: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Skeleton"], {
                        className: "w-full h-64 rounded-none"
                    }, void 0, false, {
                        fileName: "[project]/components/pdf-viewer-client.tsx",
                        lineNumber: 185,
                        columnNumber: 22
                    }, this),
                    error: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "p-4 text-sm text-destructive",
                        children: "Failed to load PDF."
                    }, void 0, false, {
                        fileName: "[project]/components/pdf-viewer-client.tsx",
                        lineNumber: 186,
                        columnNumber: 20
                    }, this),
                    children: Array.from({
                        length: numPages
                    }, (_, i)=>{
                        const page = i + 1;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            "data-page": page,
                            ref: (el)=>{
                                if (el) pageRefs.current.set(page, el);
                                else pageRefs.current.delete(page);
                            },
                            className: "mb-1",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$pdf$2f$dist$2f$Page$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Page$3e$__["Page"], {
                                pageNumber: page,
                                width: containerWidth,
                                renderTextLayer: true,
                                renderAnnotationLayer: false,
                                onGetTextSuccess: (tc)=>handleTextSuccess(page, tc),
                                customTextRenderer: highlightedItems?.page === page && highlightedItems.items.size > 0 ? ({ str, itemIndex })=>highlightedItems.items.has(itemIndex) ? `<mark style="background:rgba(250,204,21,0.45);border-radius:2px;padding:0 1px;color:transparent">${str}</mark>` : str : undefined
                            }, page, false, {
                                fileName: "[project]/components/pdf-viewer-client.tsx",
                                lineNumber: 200,
                                columnNumber: 19
                            }, this)
                        }, page, false, {
                            fileName: "[project]/components/pdf-viewer-client.tsx",
                            lineNumber: 191,
                            columnNumber: 17
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/components/pdf-viewer-client.tsx",
                    lineNumber: 182,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/pdf-viewer-client.tsx",
                lineNumber: 180,
                columnNumber: 7
            }, this),
            numPages > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute bottom-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-black/60 text-white text-xs font-medium pointer-events-none select-none backdrop-blur-sm",
                children: [
                    currentPage,
                    " / ",
                    numPages
                ]
            }, void 0, true, {
                fileName: "[project]/components/pdf-viewer-client.tsx",
                lineNumber: 226,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/pdf-viewer-client.tsx",
        lineNumber: 179,
        columnNumber: 5
    }, this);
}
_s(PdfViewer, "rnIPwhtFNCxsrEGsuKwk0/RNQ/M=");
_c = PdfViewer;
var _c;
__turbopack_context__.k.register(_c, "PdfViewer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/pdf-viewer-client.tsx [app-client] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/components/pdf-viewer-client.tsx [app-client] (ecmascript)"));
}),
]);

//# sourceMappingURL=components_pdf-viewer-client_tsx_1201gbs._.js.map