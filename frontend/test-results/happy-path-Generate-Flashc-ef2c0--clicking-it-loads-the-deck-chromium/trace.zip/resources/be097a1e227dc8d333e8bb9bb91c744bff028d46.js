(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_0v~p.hr._.js","static/chunks/components_pdf-viewer-client_tsx_1201gbs._.js","static/chunks/node_modules_react-pdf_dist_Page_TextLayer_08_emq8.css"],
    source: "dynamic"
});
