(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/pdf-viewer-client.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_0v~p.hr._.js",
  "static/chunks/components_pdf-viewer-client_tsx_1201gbs._.js",
  {
    "path": "static/chunks/node_modules_react-pdf_dist_Page_TextLayer_08_emq8.css",
    "included": [
      "[project]/node_modules/react-pdf/dist/Page/TextLayer.css [app-client] (css)"
    ]
  },
  "static/chunks/components_pdf-viewer-client_tsx_0dals2r._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/pdf-viewer-client.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);