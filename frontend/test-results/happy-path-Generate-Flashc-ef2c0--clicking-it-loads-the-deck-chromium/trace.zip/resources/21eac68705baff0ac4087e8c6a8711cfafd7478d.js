(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_next_0.62.0t._.js","static/chunks/node_modules_@supabase_postgrest-js_dist_index_mjs_0eu3ylr._.js","static/chunks/node_modules_@supabase_auth-js_dist_module_0.pzobh._.js","static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0ezz.e5._.js","static/chunks/node_modules_@base-ui_react_esm_0_fh61q._.js","static/chunks/node_modules_0qrjxiy._.js","static/chunks/_1343vi_._.js"],
    source: "dynamic"
});
